# Tugas 1 praktikum modul 1
print("Biodata diri")

nama=str(input("Nama :"))
nim=int(input("NIM :"))
angkatan=int(input("Angkatan :"))
jurusan=str(input("Jurusan :"))
fakultas=str(input("Fakultas :"))

print("Praktikum algoritma dan pemrograman")
print("Nama:",nama)
print("NIM:",nim)
print("Angkatan:",angkatan)
print("Jurusan:",jurusan)
print("Fakultas:",fakultas)
print("Universitas Trunojoyo Madura")