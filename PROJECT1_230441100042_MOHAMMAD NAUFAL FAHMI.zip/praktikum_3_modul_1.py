# Tugas 3 praktikum modul 1
print("konversi celcius ke fahrenheit,reamur, dan kelvin")

print("rumus celcius ke fahrenheit")
suhu_celcius = float(input("masukkan suhu celcius:"))
fahrenheit = ((9/5) * suhu_celcius) +32
print("jadi suhu fahrenheitnya adalah",fahrenheit, "F")

print("rumus celcius ke reamur")
suhu_celcius = float(input("masukkan suhu celcius:"))
reamur = ((4/5)*suhu_celcius)
print("jadi suhu reamurnya adalah", reamur, "R")

print("rumus celcius ke kelvin")
suhu_celcius = float(input("masukkan suhu celcius:"))
kelvin = suhu_celcius + 273
print("jadi suhu kelvinnya adalah", kelvin, "K")




