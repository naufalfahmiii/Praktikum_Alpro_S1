umur = int(input("masukkan umur anda :"))
if umur > 50 :
    print("tua")
elif umur > 25 :
    print("dewasa")
elif umur > 17 :
    print("muda")
elif umur > 7 :
    print("anak - anak")
else :
    print("data tidak termasuk pada kategori")