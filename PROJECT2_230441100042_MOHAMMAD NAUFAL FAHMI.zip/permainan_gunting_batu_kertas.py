pemain_1 = input("pemain 1 memilih :").lower()
pemain_2 = input("pemain 2 memilih :").lower()

a = "gunting"
b = "batu"
c = "kertas"

if pemain_1 == pemain_2:
    print("kedua pemain seri")
elif pemain_1 == a :
    if pemain_2 == b :
        print("pemenangnya pemain 2")
    else :
        print("pemenangnya pemain 1")
elif pemain_1 == c :
    if pemain_2 == a:
        print("pemenangnya pemain 2")
    else :
        print("pemenangnya pemain 1")
elif pemain_1 == b :
    if pemain_2 == c:
        print("pemenangnya pemain 2")
    else :
        print("pemenangnya pemain 1")
else :
    print("pilihan hanya ada gunting/batu/kertas")





# elif pemain_1 == pemain_2 :
#     print("seri")
