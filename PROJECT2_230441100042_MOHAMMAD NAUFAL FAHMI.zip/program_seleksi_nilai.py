nama = input("masukkan nama :")
nim = input("masukkan nim :")
nilai_tugas = float(input("masukkan nilai tugas :"))
nilai_UTS = float(input("masukkan nilai UTS :"))
nilai_UAS = float(input("masukkan nilai UAS :"))
nilai_tugas_akhir = float(input("masukkan nilai tugas akhir :"))
rata_rata = (nilai_tugas +nilai_UTS + nilai_UAS + nilai_tugas_akhir)/4
print("Nilai rata - rata nilai anda :",rata_rata)
if rata_rata <= 100 and rata_rata >= 80 :
    print("Anda mendapat A")
elif rata_rata <= 80 and rata_rata >= 70 :
    print("Anda mendapat B")
elif rata_rata <=70 and rata_rata >= 60 :
    print("Anda mendapatkan C")
elif rata_rata <=60 and rata_rata >= 40 :
    print("Anda mendapatkan D")
elif rata_rata <= 40 and rata_rata >= 0 :
    print("Anda mendapatkan E")
else :
    print("Tidak Berpredikat")